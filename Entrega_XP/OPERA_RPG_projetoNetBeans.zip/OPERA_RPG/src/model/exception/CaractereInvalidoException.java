package model.exception;


public class CaractereInvalidoException extends Exception {

    public CaractereInvalidoException(String string) {
        super(string);
    }
    
    public CaractereInvalidoException() {
    }
    
}
