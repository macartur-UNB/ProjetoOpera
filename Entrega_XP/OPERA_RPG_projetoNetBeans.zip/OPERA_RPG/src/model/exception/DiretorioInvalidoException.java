
package model.exception;

public class DiretorioInvalidoException extends Exception{

    public DiretorioInvalidoException() {
    }

    public DiretorioInvalidoException(String message) {
        super(message);
    }
        
}
