
package model.exception;


public class DescricaoInvalidaException  extends Exception{

    public DescricaoInvalidaException() {
    }

    public DescricaoInvalidaException(String message) {
        super(message);
    }
    
}
