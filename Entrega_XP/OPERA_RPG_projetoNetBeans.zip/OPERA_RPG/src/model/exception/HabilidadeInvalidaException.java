package model.exception;

public class HabilidadeInvalidaException extends Exception{
    
    public HabilidadeInvalidaException(){
        
    }
    public HabilidadeInvalidaException(String mensagem){
        super(mensagem);
    }
    
}
